from sklearn.linear_model import LinearRegression, BayesianRidge, ElasticNet, Lasso
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import RobustScaler
from sklearn.ensemble import VotingRegressor

#BUILD MODEL HERE
linear = LinearRegression()
bayesian = BayesianRidge(alpha_1= 3.3947835934271864, alpha_2= 3.0272144387040733e-05, fit_intercept = True)
lasso = make_pipeline(RobustScaler(), Lasso(alpha =0.0083, random_state=1))
ENet = make_pipeline(RobustScaler(), ElasticNet(alpha=0.0005, l1_ratio=.9, random_state=3))

models = [('baye', bayesian), ('lasso', lasso), ('enet', ENet), ('linear', linear)]
voting_reg = VotingRegressor(estimators=models)

def get_predictions(test_case, X, Y):
    voting_reg.fit(X, Y)
    y_pred = voting_reg.predict(test_case)
    print(y_pred)
    return round(y_pred[0])
